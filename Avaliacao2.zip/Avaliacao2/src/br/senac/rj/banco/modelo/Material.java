package br.senac.rj.banco.modelo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Material {
    private int codMaterial;
    private int idMaterial;
    private String descMaterial;
    protected double qtdeMaterial;
    public static int totalCadastrado;

    public Material() {
        this.descMaterial = "";
        Material.totalCadastrado++;
    }

    public Material(int codMaterial, int idMaterial) {
        this();
        this.codMaterial = codMaterial;
        this.idMaterial = idMaterial;
    }

    public String getdescMaterial() {
        return descMaterial;
    }

    public void setdescMaterial(String descMaterial) {
        this.descMaterial = descMaterial;
    }

    public int getcodMaterial() {
        return codMaterial;
    }

    public void setcodMaterial(int codMaterial) {
        this.codMaterial = codMaterial;
    }

    public int getidMaterial() {
        return idMaterial;
    }

    public void setidMaterial(int idMaterial) {
        this.idMaterial = idMaterial;
    }

    public double getQtdeMaterial() {
        return qtdeMaterial;
    }

    public void deposita(double valor) {
        this.qtdeMaterial += valor;
    }

    public boolean saca(double valor) {
        if (this.qtdeMaterial >= valor) {
            this.qtdeMaterial -= valor;
            return true;
        } else {
            return false;
        }
    }

    public boolean cadastrarMaterial(int codMaterial, int idMaterial, String descMaterial) {
        Connection conexao = null;
        try {
            conexao = Conexao.conectaBanco();
            String sql = "insert into material set codMaterial=?, idMaterial=?, descMaterial=?, qtdeMaterial=0;";
            PreparedStatement ps = conexao.prepareStatement(sql);
            ps.setInt(1, codMaterial);
            ps.setInt(2, idMaterial);
            ps.setString(3, descMaterial);
            int totalRegistrosAfetados = ps.executeUpdate();
            if (totalRegistrosAfetados == 0) {
                System.out.println("Não foi feito o cadastro!!");
                return false;
            }
            System.out.println("Cadastro realizado!");
            return true;
        } catch (SQLException erro) {
            System.out.println("Erro ao cadastrar material: " + erro.toString());
            return false;
        } finally {
            Conexao.fechaConexao(conexao);
        }
    }

    public boolean consultarMaterial(int codMaterial, int idMaterial) {
        Connection conexao = null;
        try {
            conexao = Conexao.conectaBanco();
            String sql = "select * from material where codMaterial=? and idMaterial=?";
            PreparedStatement ps = conexao.prepareStatement(sql);
            ps.setInt(1, codMaterial);
            ps.setInt(2, idMaterial);
            ResultSet rs = ps.executeQuery();
            if (!rs.isBeforeFirst()) {
                System.out.println("Material não cadastrado!");
                return false;
            } else {
                while (rs.next()) {
                    this.codMaterial = rs.getInt("codMaterial");
                    this.idMaterial = rs.getInt("idMaterial");
                    this.descMaterial = rs.getString("descMaterial");
                    this.qtdeMaterial = rs.getDouble("qtdeMaterial");
                }
                return true;
            }
        } catch (SQLException erro) {
            System.out.println("Erro ao consultar material: " + erro.toString());
            return false;
        } finally {
            Conexao.fechaConexao(conexao);
        }
    }

    public boolean consultarMaterialPorCodigo(int codMaterial) {
        Connection conexao = null;
        try {
            conexao = Conexao.conectaBanco();
            String sql = "select * from material where codMaterial=?";
            PreparedStatement ps = conexao.prepareStatement(sql);
            ps.setInt(1, codMaterial);
            ResultSet rs = ps.executeQuery();
            return rs.isBeforeFirst();
        } catch (SQLException erro) {
            System.out.println("Erro ao consultar material por código: " + erro.toString());
            return false;
        } finally {
            Conexao.fechaConexao(conexao);
        }
    }

    public boolean consultarMaterialPorId(int idMaterial) {
        Connection conexao = null;
        try {
            conexao = Conexao.conectaBanco();
            String sql = "select * from material where idMaterial=?";
            PreparedStatement ps = conexao.prepareStatement(sql);
            ps.setInt(1, idMaterial);
            ResultSet rs = ps.executeQuery();
            return rs.isBeforeFirst();
        } catch (SQLException erro) {
            System.out.println("Erro ao consultar material por ID: " + erro.toString());
            return false;
        } finally {
            Conexao.fechaConexao(conexao);
        }
    }

    public boolean consultarMaterialPorNome(String descMaterial) {
        Connection conexao = null;
        try {
            conexao = Conexao.conectaBanco();
            String sql = "select * from material where descMaterial=?";
            PreparedStatement ps = conexao.prepareStatement(sql);
            ps.setString(1, descMaterial);
            ResultSet rs = ps.executeQuery();
            return rs.isBeforeFirst();
        } catch (SQLException erro) {
            System.out.println("Erro ao consultar material por nome: " + erro.toString());
            return false;
        } finally {
            Conexao.fechaConexao(conexao);
        }
    }

    public boolean atualizarMaterial(int codMaterial, int idMaterial, String descMaterial) {
        Connection conexao = null;
        try {
            conexao = Conexao.conectaBanco();
            String sql = "update material set descMaterial=?, qtdeMaterial=? where codMaterial=? and idMaterial=?";
            PreparedStatement ps = conexao.prepareStatement(sql);
            ps.setString(1, descMaterial);
            ps.setDouble(2, qtdeMaterial);
            ps.setInt(3, codMaterial);
            ps.setInt(4, idMaterial);
            int totalRegistrosAfetados = ps.executeUpdate();
            if (totalRegistrosAfetados == 0) {
                System.out.println("Não foi possível atualizar o material!");
                return false;
            }
            System.out.println("Material atualizado com sucesso!");
            return true;
        } catch (SQLException erro) {
            System.out.println("Erro ao atualizar material: " + erro.toString());
            return false;
        } finally {
            Conexao.fechaConexao(conexao);
        }
    }

    public boolean deletarMaterial(int codMaterial, int idMaterial) {
        Connection conexao = null;
        try {
            conexao = Conexao.conectaBanco();
            String sql = "delete from material where codMaterial=? and idMaterial=?";
            PreparedStatement ps = conexao.prepareStatement(sql);
            ps.setInt(1, codMaterial);
            ps.setInt(2, idMaterial);
            int totalRegistrosAfetados = ps.executeUpdate();
            if (totalRegistrosAfetados == 0) {
                System.out.println("Não foi possível deletar o material!");
                return false;
            }
            System.out.println("Material deletado com sucesso!");
            return true;
        } catch (SQLException erro) {
            System.out.println("Erro ao deletar material: " + erro.toString());
            return false;
        } finally {
            Conexao.fechaConexao(conexao);
        }
    }
}
