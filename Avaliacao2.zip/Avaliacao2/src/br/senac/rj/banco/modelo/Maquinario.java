package br.senac.rj.banco.modelo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Maquinario {
    private int idMaquina;
    private String tipo;
    private String fabricante;
    private String status;

    // Getters e Setters
    public int getIdMaquina() {
        return idMaquina;
    }

    public void setIdMaquina(int idMaquina) {
        this.idMaquina = idMaquina;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getFabricante() {
        return fabricante;
    }

    public void setFabricante(String fabricante) {
        this.fabricante = fabricante;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    // Método para inserir um maquinario no banco de dados
    public boolean inserirMaquinario(int idMaquina, String tipo, String fabricante, String status) {
        String sql = "insert into maquinario set idMaquina=?, tipo=?, fabricante=?, status=?";
        try (Connection con = Conexao.conectaBanco();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, idMaquina);
            ps.setString(2, tipo);
            ps.setString(3, fabricante);
            ps.setString(4, status);
            ps.executeUpdate();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Método para consultar um maquinario por idMaquina
    public Maquinario consultarMaquinarioPorId(int idMaquina) {
        String sql = "select * from maquinario where idMaquina=?";
        try (Connection con = Conexao.conectaBanco();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, idMaquina);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    Maquinario maquinario = new Maquinario();
                    maquinario.setIdMaquina(rs.getInt("idMaquina"));
                    maquinario.setTipo(rs.getString("tipo"));
                    maquinario.setFabricante(rs.getString("fabricante"));
                    maquinario.setStatus(rs.getString("status"));
                    return maquinario;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    // Método para atualizar um maquinario no banco de dados
    public boolean atualizarMaquinario(int idMaquina, String tipo, String fabricante, String status) {
        String sql = "update maquinario set tipo=?, fabricante=?, status=? where idMaquina=?";
        try (Connection con = Conexao.conectaBanco();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, tipo);
            ps.setString(2, fabricante);
            ps.setString(3, status);
            ps.setInt(4, idMaquina);
            ps.executeUpdate();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Método para deletar um maquinario no banco de dados
    public boolean deletarMaquinario(int idMaquina) {
        String sql = "delete from maquinario where idMaquina=?";
        try (Connection con = Conexao.conectaBanco();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, idMaquina);
            ps.executeUpdate();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}
