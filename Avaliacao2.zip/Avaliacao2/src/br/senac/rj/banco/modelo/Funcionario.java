package br.senac.rj.banco.modelo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Funcionario {
    private int idFuncionario;
    private int cpf;
    private String nome;
    private int idade;

    // Getters e Setters

    public int getIdFuncionario() {
        return idFuncionario;
    }

    public void setIdFuncionario(int idFuncionario) {
        this.idFuncionario = idFuncionario;
    }

    public int getCpf() {
        return cpf;
    }

    public void setCpf(int cpf) {
        this.cpf = cpf;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getIdade() {
        return idade;
    }

    public void setIdade(int idade) {
        this.idade = idade;
    }

    // Método para inserir um funcionário
    public boolean inserirFuncionario(int idFuncionario, int cpf, String nome, int idade) {
        Connection conexao = null;
        try {
            conexao = Conexao.conectaBanco();
            String sql = "insert into funcionario set idFuncionario=?, cpf=?, nome=?, idade=?";
            PreparedStatement ps = conexao.prepareStatement(sql);
            ps.setInt(1, idFuncionario);
            ps.setInt(2, cpf);
            ps.setString(3, nome);
            ps.setInt(4, idade);
            int totalRegistrosAfetados = ps.executeUpdate();
            if (totalRegistrosAfetados == 0) {
                System.out.println("Não foi possível inserir o funcionário!");
                return false;
            }
            System.out.println("Funcionário inserido com sucesso!");
            return true;
        } catch (SQLException erro) {
            System.out.println("Erro ao inserir funcionário: " + erro.toString());
            return false;
        } finally {
            Conexao.fechaConexao(conexao);
        }
    }

    // Método para consultar um funcionário por ID
    public boolean consultarFuncionarioPorId(int idFuncionario) {
        Connection conexao = null;
        try {
            conexao = Conexao.conectaBanco();
            String sql = "select * from funcionario where idFuncionario=?";
            PreparedStatement ps = conexao.prepareStatement(sql);
            ps.setInt(1, idFuncionario);
            ResultSet rs = ps.executeQuery();
            if (!rs.next()) {
                System.out.println("Funcionário não encontrado!");
                return false;
            } else {
                this.idFuncionario = rs.getInt("idFuncionario");
                this.cpf = rs.getInt("cpf");
                this.nome = rs.getString("nome");
                this.idade = rs.getInt("idade");
                return true;
            }
        } catch (SQLException erro) {
            System.out.println("Erro ao consultar funcionário: " + erro.toString());
            return false;
        } finally {
            Conexao.fechaConexao(conexao);
        }
    }

    // Método para consultar um funcionário por CPF
    public boolean consultarFuncionarioPorCpf(int cpf) {
        Connection conexao = null;
        try {
            conexao = Conexao.conectaBanco();
            String sql = "select * from funcionario where cpf=?";
            PreparedStatement ps = conexao.prepareStatement(sql);
            ps.setInt(1, cpf);
            ResultSet rs = ps.executeQuery();
            if (!rs.next()) {
                System.out.println("Funcionário não encontrado!");
                return false;
            } else {
                this.idFuncionario = rs.getInt("idFuncionario");
                this.cpf = rs.getInt("cpf");
                this.nome = rs.getString("nome");
                this.idade = rs.getInt("idade");
                return true;
            }
        } catch (SQLException erro) {
            System.out.println("Erro ao consultar funcionário: " + erro.toString());
            return false;
        } finally {
            Conexao.fechaConexao(conexao);
        }
    }

    // Método para deletar um funcionário por ID
    public static boolean deletarFuncionario(int idFuncionario) {
        Connection conexao = null;
        try {
            conexao = Conexao.conectaBanco();
            String sql = "delete from funcionario where idFuncionario=?";
            PreparedStatement ps = conexao.prepareStatement(sql);
            ps.setInt(1, idFuncionario);
            int totalRegistrosAfetados = ps.executeUpdate();
            if (totalRegistrosAfetados == 0) {
                System.out.println("Não foi possível deletar o funcionário!");
                return false;
            }
            System.out.println("Funcionário deletado com sucesso!");
            return true;
        } catch (SQLException erro) {
            System.out.println("Erro ao deletar funcionário: " + erro.toString());
            return false;
        } finally {
            Conexao.fechaConexao(conexao);
        }
    }
}
