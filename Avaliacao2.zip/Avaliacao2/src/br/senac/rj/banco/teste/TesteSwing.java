package br.senac.rj.banco.teste;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.UIManager;
import javax.swing.WindowConstants;

import br.senac.rj.banco.janelas.JanelaAlterarDescricao;
import br.senac.rj.banco.janelas.JanelaCadastroFuncionario;
import br.senac.rj.banco.janelas.JanelaCadastroMaquina;
import br.senac.rj.banco.janelas.JanelaCadastroMaterial;
import br.senac.rj.banco.janelas.JanelaDeletarFuncionario;
import br.senac.rj.banco.janelas.JanelaDeletarMaquina;
import br.senac.rj.banco.janelas.JanelaDeletarMaterial;
import br.senac.rj.banco.janelas.JanelaEntradaSaida;

public class TesteSwing {

    public static void apresentarMenu() {
        // Define a janela
        JFrame janelaPrincipal = new JFrame("Cadastro de Material"); // Janela Normal
        janelaPrincipal.setTitle("Cadastro de Material");
        janelaPrincipal.setResizable(false); // A janela não poderá ter o tamanho ajustado
        janelaPrincipal.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        janelaPrincipal.setSize(400, 300); // Define tamanho da janela
        UIManager.put("OptionPane.yesButtonText", "Sim");
        UIManager.put("OptionPane.noButtonText", "Não");
        // Cria uma barra de menu para a janela principal
        JMenuBar menuBar = new JMenuBar();
        // Adiciona a barra de menu ao frame
        janelaPrincipal.setJMenuBar(menuBar);
        // Define e adiciona menu na barra de menu
        JMenu menuAtualizar = new JMenu("Menu");
        menuBar.add(menuAtualizar);
        // Cria e adiciona um item simples para o menu
        JMenuItem menuConta = new JMenuItem("Cadastrar Material");
        menuAtualizar.add(menuConta);
        JMenuItem entradaSaida = new JMenuItem("Entrada/Saída de Material");
        menuAtualizar.add(entradaSaida);
        JMenuItem alterarDescricao = new JMenuItem("Alterar descrição do Material");
        menuAtualizar.add(alterarDescricao);
        JMenuItem deletarMaterial = new JMenuItem("Apagar Material");
        menuAtualizar.add(deletarMaterial);
        JMenuItem cadastarFuncionario = new JMenuItem("Cadastar Funcionário");
        menuAtualizar.add(cadastarFuncionario);
        JMenuItem deletarFuncionario = new JMenuItem("Apagar Funcionário");
        menuAtualizar.add(deletarFuncionario);
        JMenuItem cadastarMaquina = new JMenuItem("Cadastar Máquina");
        menuAtualizar.add(cadastarMaquina);
        JMenuItem deletarMaquina = new JMenuItem("Apagar Máquina");
        menuAtualizar.add(deletarMaquina);
        // Criar a janela de atualização da conta
        JFrame janelaConta = JanelaCadastroMaterial.criarJanela();
        JFrame janelaEntradaSaida = JanelaEntradaSaida.criarJanela();
        JFrame janelaAlteracaoDescricao = JanelaAlterarDescricao.criarJanela();
        JFrame janelaDeletarMaterial = JanelaDeletarMaterial.criarJanela();
        JFrame janelaCadastroFuncionario = JanelaCadastroFuncionario.criarJanela();
        JFrame janelaDeletarFuncionario = JanelaDeletarFuncionario.criarJanela();
        JFrame janelaCadastroMaquina = JanelaCadastroMaquina.criarJanela();
        JFrame janelaDeletarMaquina = JanelaDeletarMaquina.criarJanela();
        // Adiciona ação para o item do menu
        menuConta.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent arg0) {
                janelaConta.setVisible(true);
            }
        });
        entradaSaida.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent arg0) {
            	janelaEntradaSaida.setVisible(true);
            }
        });
        alterarDescricao.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent arg0) {
                janelaAlteracaoDescricao.setVisible(true);
            }
        });
        deletarMaterial.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent arg0) {
            	janelaDeletarMaterial.setVisible(true);
            }
        });
        cadastarFuncionario.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent arg0) {
            	janelaCadastroFuncionario.setVisible(true);
            }
        });
        deletarFuncionario.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent arg0) {
            	janelaDeletarFuncionario.setVisible(true);
            }
        });
        cadastarMaquina.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent arg0) {
            	janelaCadastroMaquina.setVisible(true);
            }
        });
        deletarMaquina.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent arg0) {
            	janelaDeletarMaquina.setVisible(true);
            }
        });
        
        janelaPrincipal.setVisible(true);
    }

    public static void main(String[] args) {
        apresentarMenu();
    }
}
