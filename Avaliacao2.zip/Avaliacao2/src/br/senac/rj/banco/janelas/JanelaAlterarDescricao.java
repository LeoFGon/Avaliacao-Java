package br.senac.rj.banco.janelas;

import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.WindowConstants;
import br.senac.rj.banco.modelo.Material;

public class JanelaAlterarDescricao {
    public static JFrame criarJanela() {
        // Define a janela
        JFrame janela = new JFrame("Alteracao de Descricao de Material"); // Janela Normal
        janela.setResizable(false); // A janela não poderá ter o tamanho ajustado
        janela.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        janela.setSize(400, 300); // Define tamanho da janela
        // Define o layout da janela
        Container caixa = janela.getContentPane();
        caixa.setLayout(null);
        // Define os labels dos campos
        JLabel labelcodMaterial = new JLabel("Codigo do Material: ");
        JLabel labelidMaterial = new JLabel("Id do Material: ");
        JLabel labeldescMaterial = new JLabel("Nova Descricao: ");
        // Posiciona os labels na janela
        labelcodMaterial.setBounds(50, 40, 150, 20); // coluna, linha, largura, tamanho
        labelidMaterial.setBounds(50, 80, 150, 20); // coluna, linha, largura, tamanho
        labeldescMaterial.setBounds(50, 120, 150, 20); // coluna, linha, largura, tamanho
        // Define os input box
        JTextField jTextcodMaterial = new JTextField();
        JTextField jTextidMaterial = new JTextField();
        JTextField jTextdescMaterial = new JTextField();
        // Posiciona os input box
        jTextcodMaterial.setBounds(200, 40, 50, 20);
        jTextidMaterial.setBounds(200, 80, 50, 20);
        jTextdescMaterial.setBounds(200, 120, 150, 20);
        // Adiciona os rótulos e os input box na janela
        janela.add(labelcodMaterial);
        janela.add(labelidMaterial);
        janela.add(labeldescMaterial);
        janela.add(jTextcodMaterial);
        janela.add(jTextidMaterial);
        janela.add(jTextdescMaterial);
        // Define botões e a localização deles na janela
        JButton botaoAlterar = new JButton("Alterar");
        botaoAlterar.setBounds(50, 200, 100, 20);
        janela.add(botaoAlterar);
        JButton botaoLimpar = new JButton("Limpar");
        botaoLimpar.setBounds(250, 200, 100, 20);
        janela.add(botaoLimpar);
        // Define objeto material para pesquisar no banco de dados
        Material material = new Material();
        // Define ações dos botões
        botaoAlterar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    int codMaterial = Integer.parseInt(jTextcodMaterial.getText());
                    int idMaterial = Integer.parseInt(jTextidMaterial.getText());
                    String novaDescricao = jTextdescMaterial.getText().trim();
                    if (novaDescricao.isEmpty()) {
                        JOptionPane.showMessageDialog(janela, "Preencha o campo de descrição");
                        jTextdescMaterial.requestFocus();
                        return;
                    }
                    int resposta = JOptionPane.showConfirmDialog(janela, "Você tem certeza que quer alterar a descrição?", "Confirmação", JOptionPane.YES_NO_OPTION);
                    if (resposta == JOptionPane.YES_OPTION) {
                        if (!material.consultarMaterial(codMaterial, idMaterial)) {
                            JOptionPane.showMessageDialog(janela, "Material não encontrado!");
                        } else {
                            if (!material.atualizarMaterial(codMaterial, idMaterial, novaDescricao)) {
                                JOptionPane.showMessageDialog(janela, "Erro na atualização da descrição!");
                            } else {
                                JOptionPane.showMessageDialog(janela, "Descrição atualizada com sucesso!");
                            }
                        }
                    }
                } catch (Exception erro) {
                    JOptionPane.showMessageDialog(janela, "Preencha os campos corretamente!");
                }
            }
        });
        botaoLimpar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jTextcodMaterial.setText(""); // Limpar campo
                jTextidMaterial.setText(""); // Limpar campo
                jTextdescMaterial.setText(""); // Limpar campo
                jTextcodMaterial.requestFocus(); // Colocar o foco em um campo
            }
        });
        return janela;
    }
}
