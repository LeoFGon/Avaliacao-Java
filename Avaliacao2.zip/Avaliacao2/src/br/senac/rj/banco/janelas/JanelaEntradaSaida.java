package br.senac.rj.banco.janelas;

import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.WindowConstants;
import br.senac.rj.banco.modelo.Material;

public class JanelaEntradaSaida {
    public static JFrame criarJanela() {
        // Define a janela
        JFrame janela = new JFrame("Entrada/Saída de Material"); // Janela Normal
        janela.setResizable(false); // A janela não poderá ter o tamanho ajustado
        janela.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        janela.setSize(400, 300); // Define tamanho da janela
        // Define o layout da janela
        Container caixa = janela.getContentPane();
        caixa.setLayout(null);
        // Define os labels dos campos
        JLabel labelCodMaterial = new JLabel("Código do Material: ");
        JLabel labelIdMaterial = new JLabel("ID do Material: ");
        JLabel labelQtdeMaterial = new JLabel("Quantidade: ");
        // Posiciona os labels na janela
        labelCodMaterial.setBounds(50, 40, 150, 20); // coluna, linha, largura, tamanho
        labelIdMaterial.setBounds(50, 80, 150, 20); // coluna, linha, largura, tamanho
        labelQtdeMaterial.setBounds(50, 120, 150, 20); // coluna, linha, largura, tamanho
        // Define os input box
        JTextField jTextCodMaterial = new JTextField();
        JTextField jTextIdMaterial = new JTextField();
        JTextField jTextQtdeMaterial = new JTextField();
        // Define se os campos estão habilitados ou não no início
        jTextCodMaterial.setEnabled(true);
        jTextIdMaterial.setEnabled(true);
        jTextQtdeMaterial.setEnabled(true);
        // Posiciona os input box
        jTextCodMaterial.setBounds(200, 40, 150, 20);
        jTextIdMaterial.setBounds(200, 80, 150, 20);
        jTextQtdeMaterial.setBounds(200, 120, 150, 20);
        // Adiciona os rótulos e os input box na janela
        janela.add(labelCodMaterial);
        janela.add(labelIdMaterial);
        janela.add(labelQtdeMaterial);
        janela.add(jTextCodMaterial);
        janela.add(jTextIdMaterial);
        janela.add(jTextQtdeMaterial);
        // Define botões e a localização deles na janela
        JButton botaoDepositar = new JButton("Depositar");
        botaoDepositar.setBounds(50, 200, 100, 20);
        janela.add(botaoDepositar);
        JButton botaoSacar = new JButton("Sacar");
        botaoSacar.setBounds(250, 200, 100, 20);
        janela.add(botaoSacar);
        // Define objeto Material para realizar as operações
        Material material = new Material();
        // Define ações dos botões
        botaoDepositar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    int codMaterial = Integer.parseInt(jTextCodMaterial.getText());
                    int idMaterial = Integer.parseInt(jTextIdMaterial.getText());
                    double qtde = Double.parseDouble(jTextQtdeMaterial.getText());
                    if (!material.consultarMaterial(codMaterial, idMaterial)) {
                        JOptionPane.showMessageDialog(janela, "Material não cadastrado!");
                    } else {
                        material.deposita(qtde);
                        if (material.atualizarMaterial(codMaterial, idMaterial, material.getdescMaterial())) {
                            JOptionPane.showMessageDialog(janela, "Quantidade carregada com sucesso!");
                        } else {
                            JOptionPane.showMessageDialog(janela, "Erro ao atualizar o material no banco de dados!");
                        }
                    }
                } catch (Exception erro) {
                    JOptionPane.showMessageDialog(janela, "Erro ao realizar depósito: " + erro.getMessage());
                }
            }
        });
        botaoSacar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    int codMaterial = Integer.parseInt(jTextCodMaterial.getText());
                    int idMaterial = Integer.parseInt(jTextIdMaterial.getText());
                    double qtde = Double.parseDouble(jTextQtdeMaterial.getText());
                    if (!material.consultarMaterial(codMaterial, idMaterial)) {
                        JOptionPane.showMessageDialog(janela, "Material não cadastrado!");
                    } else {
                        if (material.saca(qtde)) {
                            if (material.atualizarMaterial(codMaterial, idMaterial, material.getdescMaterial())) {
                                JOptionPane.showMessageDialog(janela, "Quantidade retirada com sucesso!");
                            } else {
                                JOptionPane.showMessageDialog(janela, "Erro ao atualizar o material no banco de dados!");
                            }
                        } else {
                            JOptionPane.showMessageDialog(janela, "Quantidade insuficiente para saque!");
                        }
                    }
                } catch (Exception erro) {
                    JOptionPane.showMessageDialog(janela, "Erro ao realizar saque: " + erro.getMessage());
                }
            }
        });
        return janela;
    }
}
