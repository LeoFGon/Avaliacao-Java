package br.senac.rj.banco.janelas;

import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.WindowConstants;
import br.senac.rj.banco.modelo.Material;

public class JanelaCadastroMaterial {
    public static JFrame criarJanela() {
        // Define a janela
        JFrame janela = new JFrame("Cadastro de Material");
        janela.setResizable(false); // A janela não poderá ter o tamanho ajustado
        janela.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        janela.setSize(400, 300); // Define tamanho da janela

        // Define o layout da janela
        Container caixa = janela.getContentPane();
        caixa.setLayout(null);

        // Define os labels dos campos
        JLabel labelcodMaterial = new JLabel("Codigo do Material: ");
        JLabel labelidMaterial = new JLabel("Id do Material: ");
        JLabel labeldescMaterial = new JLabel("Descricao do Material: ");

        // Posiciona os labels na janela
        labelcodMaterial.setBounds(50, 40, 150, 20); // coluna, linha, largura, tamanho
        labelidMaterial.setBounds(50, 80, 150, 20); // coluna, linha, largura, tamanho
        labeldescMaterial.setBounds(50, 120, 150, 20); // coluna, linha, largura, tamanho

        // Define os input box
        JTextField jTextcodMaterial = new JTextField();
        JTextField jTextidMaterial = new JTextField();
        JTextField jTextdescMaterial = new JTextField();

        // Posiciona os input box
        jTextcodMaterial.setBounds(200, 40, 150, 20);
        jTextidMaterial.setBounds(200, 80, 150, 20);
        jTextdescMaterial.setBounds(200, 120, 150, 20);

        // Adiciona os rótulos e os input box na janela
        janela.add(labelcodMaterial);
        janela.add(labelidMaterial);
        janela.add(labeldescMaterial);
        janela.add(jTextcodMaterial);
        janela.add(jTextidMaterial);
        janela.add(jTextdescMaterial);

        // Define botões e a localização deles na janela
        JButton botaoGravar = new JButton("Gravar");
        botaoGravar.setBounds(50, 200, 100, 20);
        janela.add(botaoGravar);

        JButton botaoLimpar = new JButton("Limpar");
        botaoLimpar.setBounds(250, 200, 100, 20);
        janela.add(botaoLimpar);

        // Define objeto material para interação com o banco de dados
        Material material = new Material();

        // Define ações dos botões
        botaoGravar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    int codMaterial = Integer.parseInt(jTextcodMaterial.getText());
                    int idMaterial = Integer.parseInt(jTextidMaterial.getText());
                    String descMaterial = jTextdescMaterial.getText().trim(); // Remove espaços em branco

                    if (descMaterial.isEmpty()) {
                        JOptionPane.showMessageDialog(janela, "Preencha o campo do nome");
                        jTextdescMaterial.requestFocus();
                    } else {
                        if (material.consultarMaterialPorCodigo(codMaterial) || 
                            material.consultarMaterialPorId(idMaterial) || 
                            material.consultarMaterialPorNome(descMaterial)) {
                            JOptionPane.showMessageDialog(janela, "Erro: Material com o mesmo código, ID ou nome já cadastrado!");
                        } else {
                            if (material.cadastrarMaterial(codMaterial, idMaterial, descMaterial)) {
                                JOptionPane.showMessageDialog(janela, "Cadastro realizado com sucesso!");
                            } else {
                                JOptionPane.showMessageDialog(janela, "Erro no cadastro do material!");
                            }
                        }
                    }
                } catch (NumberFormatException erro) {
                    JOptionPane.showMessageDialog(janela, "Preencha os campos Código e ID do material corretamente!!");
                }
            }
        });

        botaoLimpar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jTextcodMaterial.setText(""); // Limpar campo
                jTextidMaterial.setText(""); // Limpar campo
                jTextdescMaterial.setText(""); // Limpar campo
                jTextcodMaterial.requestFocus(); // Colocar o foco em um campo
            }
        });

        return janela;
    }
}
