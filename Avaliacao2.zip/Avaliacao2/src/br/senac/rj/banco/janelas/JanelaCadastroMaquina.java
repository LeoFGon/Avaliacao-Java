package br.senac.rj.banco.janelas;

import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.WindowConstants;
import br.senac.rj.banco.modelo.Maquinario;

public class JanelaCadastroMaquina {

    public static JFrame criarJanela() {
        // Define a janela
        JFrame janela = new JFrame("Cadastro de Máquina");
        janela.setResizable(false); // A janela não poderá ter o tamanho ajustado
        janela.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        janela.setSize(400, 300); // Define tamanho da janela

        // Define o layout da janela
        Container caixa = janela.getContentPane();
        caixa.setLayout(null);

        // Define os labels dos campos
        JLabel labelIdMaquina = new JLabel("ID da Máquina:");
        JLabel labelTipo = new JLabel("Tipo:");
        JLabel labelFabricante = new JLabel("Fabricante:");
        JLabel labelStatus = new JLabel("Status:");

        // Posiciona os labels na janela
        labelIdMaquina.setBounds(50, 40, 150, 20);
        labelTipo.setBounds(50, 80, 150, 20);
        labelFabricante.setBounds(50, 120, 150, 20);
        labelStatus.setBounds(50, 160, 150, 20);

        // Define os input box
        JTextField jTextIdMaquina = new JTextField();
        JTextField jTextFabricante = new JTextField();

        // Posiciona os input box
        jTextIdMaquina.setBounds(200, 40, 150, 20);
        jTextFabricante.setBounds(200, 120, 150, 20);

        // Define JComboBox para Tipo
        String[] tipos = {"Caminhão", "Escavadeira", "RetroEscavadeira", "Empilhadeira", "Trator"};
        JComboBox<String> comboTipo = new JComboBox<>(tipos);
        comboTipo.setBounds(200, 80, 150, 20);

        // Define JComboBox para Status
        String[] status = {"Operando", "Em manutenção"};
        JComboBox<String> comboStatus = new JComboBox<>(status);
        comboStatus.setBounds(200, 160, 150, 20);

        // Adiciona os rótulos e os input box na janela
        janela.add(labelIdMaquina);
        janela.add(labelTipo);
        janela.add(labelFabricante);
        janela.add(labelStatus);
        janela.add(jTextIdMaquina);
        janela.add(jTextFabricante);
        janela.add(comboTipo);
        janela.add(comboStatus);

        // Define botões e a localização deles na janela
        JButton botaoGravar = new JButton("Gravar");
        botaoGravar.setBounds(50, 200, 100, 20);
        janela.add(botaoGravar);

        JButton botaoLimpar = new JButton("Limpar");
        botaoLimpar.setBounds(250, 200, 100, 20);
        janela.add(botaoLimpar);

        // Define objeto maquinario para interação com o banco de dados
        Maquinario maquinario = new Maquinario();

        // Define ações dos botões
        botaoGravar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    int idMaquina = Integer.parseInt(jTextIdMaquina.getText());
                    String tipo = (String) comboTipo.getSelectedItem();
                    String fabricante = jTextFabricante.getText().trim(); // Remove espaços em branco
                    String status = (String) comboStatus.getSelectedItem();

                    if (fabricante.isEmpty()) {
                        JOptionPane.showMessageDialog(janela, "Preencha o campo Fabricante");
                        jTextFabricante.requestFocus();
                    } else {
                        if (maquinario.consultarMaquinarioPorId(idMaquina) != null) {
                            JOptionPane.showMessageDialog(janela, "Erro: Máquina com o mesmo ID já cadastrada!");
                        } else {
                            if (maquinario.inserirMaquinario(idMaquina, tipo, fabricante, status)) {
                                JOptionPane.showMessageDialog(janela, "Cadastro realizado com sucesso!");
                            } else {
                                JOptionPane.showMessageDialog(janela, "Erro no cadastro da máquina!");
                            }
                        }
                    }
                } catch (NumberFormatException erro) {
                    JOptionPane.showMessageDialog(janela, "Preencha o campo ID da máquina corretamente!!");
                }
            }
        });

        botaoLimpar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                jTextIdMaquina.setText(""); // Limpar campo
                jTextFabricante.setText(""); // Limpar campo
                comboTipo.setSelectedIndex(0); // Resetar combo
                comboStatus.setSelectedIndex(0); // Resetar combo
                jTextIdMaquina.requestFocus(); // Colocar o foco em um campo
            }
        });

        return janela;
    }
}
