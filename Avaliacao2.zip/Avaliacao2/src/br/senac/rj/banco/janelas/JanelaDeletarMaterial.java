package br.senac.rj.banco.janelas;

import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.WindowConstants;

import br.senac.rj.banco.modelo.Material;

public class JanelaDeletarMaterial {

    public static JFrame criarJanela() {
        // Define a janela
        JFrame janela = new JFrame("Deletar Material");
        janela.setResizable(false); // A janela não poderá ter o tamanho ajustado
        janela.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        janela.setSize(400, 200); // Define tamanho da janela

        // Define o layout da janela
        Container caixa = janela.getContentPane();
        caixa.setLayout(null);

        // Define os labels e campos de entrada
        JLabel labelCodMaterial = new JLabel("Código do Material:");
        labelCodMaterial.setBounds(50, 40, 150, 20);

        JTextField campoCodMaterial = new JTextField();
        campoCodMaterial.setBounds(200, 40, 150, 20);

        JLabel labelIdMaterial = new JLabel("ID do Material:");
        labelIdMaterial.setBounds(50, 70, 150, 20);

        JTextField campoIdMaterial = new JTextField();
        campoIdMaterial.setBounds(200, 70, 150, 20);

        // Define botões e a localização deles na janela
        JButton botaoDeletar = new JButton("Deletar");
        botaoDeletar.setBounds(100, 120, 100, 20);

        JButton botaoCancelar = new JButton("Cancelar");
        botaoCancelar.setBounds(220, 120, 100, 20);

        // Adiciona os componentes na janela
        janela.add(labelCodMaterial);
        janela.add(campoCodMaterial);
        janela.add(labelIdMaterial);
        janela.add(campoIdMaterial);
        janela.add(botaoDeletar);
        janela.add(botaoCancelar);

        // Define ação do botão Deletar
        botaoDeletar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String codMaterialStr = campoCodMaterial.getText();
                String idMaterialStr = campoIdMaterial.getText();
                
                if (codMaterialStr.isEmpty() || idMaterialStr.isEmpty()) {
                    JOptionPane.showMessageDialog(janela, "Digite o Código e ID do material.");
                    return;
                }
                
                int codMaterial = Integer.parseInt(codMaterialStr);
                int idMaterial = Integer.parseInt(idMaterialStr);
                
                // Confirmação antes de deletar
                int confirmacao = JOptionPane.showConfirmDialog(janela, "Tem certeza que deseja deletar o material?");
                if (confirmacao == JOptionPane.YES_OPTION) {
                    Material material = new Material();
                    boolean deletado = material.deletarMaterial(codMaterial, idMaterial);
                    if (deletado) {
                        JOptionPane.showMessageDialog(janela, "Material deletado com sucesso!");
                        campoCodMaterial.setText(""); // Limpa o campo após a deleção
                        campoIdMaterial.setText(""); // Limpa o campo após a deleção
                    } else {
                        JOptionPane.showMessageDialog(janela, "Erro ao deletar material.");
                    }
                }
            }
        });

        // Define ação do botão Cancelar
        botaoCancelar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                janela.dispose(); // Fecha a janela
            }
        });

        return janela;
    }
}
