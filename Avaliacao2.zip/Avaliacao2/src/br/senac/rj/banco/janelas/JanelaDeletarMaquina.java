package br.senac.rj.banco.janelas;

import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.WindowConstants;
import br.senac.rj.banco.modelo.Maquinario;

public class JanelaDeletarMaquina {

    public static JFrame criarJanela() {
        // Define a janela
        JFrame janela = new JFrame("Deletar Maquinário");
        janela.setResizable(false); // A janela não poderá ter o tamanho ajustado
        janela.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        janela.setSize(400, 200); // Define tamanho da janela

        // Define o layout da janela
        Container caixa = janela.getContentPane();
        caixa.setLayout(null);

        // Define os labels e campos de entrada
        JLabel labelIdMaquinario = new JLabel("ID do Maquinário:");
        labelIdMaquinario.setBounds(50, 40, 150, 20);

        JTextField campoIdMaquinario = new JTextField();
        campoIdMaquinario.setBounds(200, 40, 150, 20);

        // Define botões e a localização deles na janela
        JButton botaoDeletar = new JButton("Deletar");
        botaoDeletar.setBounds(100, 100, 100, 20);

        JButton botaoCancelar = new JButton("Cancelar");
        botaoCancelar.setBounds(220, 100, 100, 20);

        // Adiciona os componentes na janela
        janela.add(labelIdMaquinario);
        janela.add(campoIdMaquinario);
        janela.add(botaoDeletar);
        janela.add(botaoCancelar);

        // Cria uma instância de Maquinario
        Maquinario maquinario = new Maquinario();

        // Define ação do botão Deletar
        botaoDeletar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String idMaquinarioStr = campoIdMaquinario.getText();
                if (idMaquinarioStr.isEmpty()) {
                    JOptionPane.showMessageDialog(janela, "Digite o ID do maquinário.");
                    return;
                }

                int idMaquinario = Integer.parseInt(idMaquinarioStr);

                // Confirmação antes de deletar
                int confirmacao = JOptionPane.showConfirmDialog(janela, "Tem certeza que deseja deletar o maquinário?");
                if (confirmacao == JOptionPane.YES_OPTION) {
                    boolean deletado = maquinario.deletarMaquinario(idMaquinario);
                    if (deletado) {
                        JOptionPane.showMessageDialog(janela, "Maquinário deletado com sucesso!");
                        campoIdMaquinario.setText(""); // Limpa o campo após a deleção
                    } else {
                        JOptionPane.showMessageDialog(janela, "Erro ao deletar maquinário.");
                    }
                }
            }
        });

        // Define ação do botão Cancelar
        botaoCancelar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                janela.dispose(); // Fecha a janela
            }
        });

        return janela;
    }
}
