package br.senac.rj.banco.janelas;

import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.WindowConstants;
import br.senac.rj.banco.modelo.Funcionario;

public class JanelaCadastroFuncionario {
    public static JFrame criarJanela() {
        // Define a janela
        JFrame janela = new JFrame("Cadastro de Funcionário");
        janela.setResizable(false); // A janela não poderá ter o tamanho ajustado
        janela.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        janela.setSize(400, 300); // Define tamanho da janela

        // Define o layout da janela
        Container caixa = janela.getContentPane();
        caixa.setLayout(null);

        // Define os labels dos campos
        JLabel labelIdFuncionario = new JLabel("ID do Funcionário: ");
        JLabel labelCpf = new JLabel("CPF: ");
        JLabel labelNome = new JLabel("Nome: ");
        JLabel labelIdade = new JLabel("Idade: ");

        // Posiciona os labels na janela
        labelIdFuncionario.setBounds(50, 40, 150, 20); // coluna, linha, largura, tamanho
        labelCpf.setBounds(50, 80, 150, 20); // coluna, linha, largura, tamanho
        labelNome.setBounds(50, 120, 150, 20); // coluna, linha, largura, tamanho
        labelIdade.setBounds(50, 160, 150, 20); // coluna, linha, largura, tamanho

        // Define os input box
        JTextField jTextIdFuncionario = new JTextField();
        JTextField jTextCpf = new JTextField();
        JTextField jTextNome = new JTextField();
        JTextField jTextIdade = new JTextField();

        // Posiciona os input box
        jTextIdFuncionario.setBounds(200, 40, 150, 20);
        jTextCpf.setBounds(200, 80, 150, 20);
        jTextNome.setBounds(200, 120, 150, 20);
        jTextIdade.setBounds(200, 160, 150, 20);

        // Adiciona os rótulos e os input box na janela
        janela.add(labelIdFuncionario);
        janela.add(labelCpf);
        janela.add(labelNome);
        janela.add(labelIdade);
        janela.add(jTextIdFuncionario);
        janela.add(jTextCpf);
        janela.add(jTextNome);
        janela.add(jTextIdade);

        // Define botões e a localização deles na janela
        JButton botaoGravar = new JButton("Gravar");
        botaoGravar.setBounds(50, 200, 100, 20);
        janela.add(botaoGravar);

        JButton botaoLimpar = new JButton("Limpar");
        botaoLimpar.setBounds(250, 200, 100, 20);
        janela.add(botaoLimpar);

        // Define objeto funcionário para interação com o banco de dados
        Funcionario funcionario = new Funcionario();

        // Define ações dos botões
        botaoGravar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    int idFuncionario = Integer.parseInt(jTextIdFuncionario.getText());
                    int cpf = Integer.parseInt(jTextCpf.getText());
                    String nome = jTextNome.getText().trim(); // Remove espaços em branco
                    int idade = Integer.parseInt(jTextIdade.getText());

                    if (nome.isEmpty()) {
                        JOptionPane.showMessageDialog(janela, "Preencha o campo do nome");
                        jTextNome.requestFocus();
                    } else {
                        // Verifica se o funcionário já existe pelo ID ou CPF
                        if (funcionario.consultarFuncionarioPorId(idFuncionario)) {
                            JOptionPane.showMessageDialog(janela, "Erro: Funcionário com o mesmo ID já cadastrado!");
                        } else if (funcionario.consultarFuncionarioPorCpf(cpf)) {
                            JOptionPane.showMessageDialog(janela, "Erro: Funcionário com o mesmo CPF já cadastrado!");
                        } else {
                            // Insere o funcionário no banco de dados
                            if (funcionario.inserirFuncionario(idFuncionario, cpf, nome, idade)) {
                                JOptionPane.showMessageDialog(janela, "Cadastro realizado com sucesso!");
                                // Limpa os campos após o cadastro
                                jTextIdFuncionario.setText("");
                                jTextCpf.setText("");
                                jTextNome.setText("");
                                jTextIdade.setText("");
                                jTextIdFuncionario.requestFocus(); // Coloca o foco no campo ID
                            } else {
                                JOptionPane.showMessageDialog(janela, "Erro no cadastro do funcionário!");
                            }
                        }
                    }
                } catch (NumberFormatException erro) {
                    JOptionPane.showMessageDialog(janela, "Preencha os campos ID, CPF e idade corretamente!");
                }
            }
        });

        botaoLimpar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Limpa todos os campos
                jTextIdFuncionario.setText("");
                jTextCpf.setText("");
                jTextNome.setText("");
                jTextIdade.setText("");
                jTextIdFuncionario.requestFocus(); // Coloca o foco no campo ID
            }
        });

        return janela;
    }
}
