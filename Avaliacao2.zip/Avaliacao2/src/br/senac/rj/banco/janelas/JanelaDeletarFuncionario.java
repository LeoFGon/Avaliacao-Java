package br.senac.rj.banco.janelas;

import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.WindowConstants;

import br.senac.rj.banco.modelo.Funcionario;

public class JanelaDeletarFuncionario {

    public static JFrame criarJanela() {
        // Define a janela
        JFrame janela = new JFrame("Deletar Funcionário");
        janela.setResizable(false); // A janela não poderá ter o tamanho ajustado
        janela.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        janela.setSize(400, 200); // Define tamanho da janela

        // Define o layout da janela
        Container caixa = janela.getContentPane();
        caixa.setLayout(null);

        // Define os labels e campos de entrada
        JLabel labelIdFuncionario = new JLabel("ID do Funcionário:");
        labelIdFuncionario.setBounds(50, 40, 150, 20);

        JTextField campoIdFuncionario = new JTextField();
        campoIdFuncionario.setBounds(200, 40, 150, 20);

        // Define botões e a localização deles na janela
        JButton botaoDeletar = new JButton("Deletar");
        botaoDeletar.setBounds(100, 100, 100, 20);

        JButton botaoCancelar = new JButton("Cancelar");
        botaoCancelar.setBounds(220, 100, 100, 20);

        // Adiciona os componentes na janela
        janela.add(labelIdFuncionario);
        janela.add(campoIdFuncionario);
        janela.add(botaoDeletar);
        janela.add(botaoCancelar);

        // Define ação do botão Deletar
        botaoDeletar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String idFuncionarioStr = campoIdFuncionario.getText();
                if (idFuncionarioStr.isEmpty()) {
                    JOptionPane.showMessageDialog(janela, "Digite o ID do funcionário.");
                    return;
                }
                
                int idFuncionario = Integer.parseInt(idFuncionarioStr);
                
                // Confirmação antes de deletar
                int confirmacao = JOptionPane.showConfirmDialog(janela, "Tem certeza que deseja deletar o funcionário?");
                if (confirmacao == JOptionPane.YES_OPTION) {
                    boolean deletado = Funcionario.deletarFuncionario(idFuncionario);
                    if (deletado) {
                        JOptionPane.showMessageDialog(janela, "Funcionário deletado com sucesso!");
                        campoIdFuncionario.setText(""); // Limpa o campo após a deleção
                    } else {
                        JOptionPane.showMessageDialog(janela, "Erro ao deletar funcionário.");
                    }
                }
            }
        });

        // Define ação do botão Cancelar
        botaoCancelar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                janela.dispose(); // Fecha a janela
            }
        });

        return janela;
    }
}
